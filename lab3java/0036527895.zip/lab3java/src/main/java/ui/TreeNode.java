package ui;

public interface TreeNode {}
