package ui;

public enum AlgorithmsEnum {
    bfs,
    ucs,
    astar,
    check
}
